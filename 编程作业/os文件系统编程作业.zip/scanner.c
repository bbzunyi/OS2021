#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

int stringChrR (const char *string, char token, int *size) {
	int i = 0;
	if (string == NULL) {
		*size = 0;
		return -1;
	}
	while (string[i] != 0)
		i ++;
	*size = i;
	while (i > -1) {
		if (token == string[i]) {
			*size = i;
			return 0;
		}
		else
			i --;
	}
	return -1;
}

int stringLen (const char *string) {
	int i = 0;
	if (string == NULL)
		return 0;
	while (string[i] != 0)
		i ++;
	return i;
}

void dir_oper(char const*path){
    struct  dirent*filename;
    struct stat s_buf;
    DIR *dp = opendir(path);
    while(filename = readdir(dp))
	{
		/*判断一个文件是目录还是一个普通文件*/
		char file_path[200];
		bzero(file_path,200);
		strcat(file_path,path);
		strcat(file_path,"/");
		strcat(file_path,filename->d_name);
		
		/*在linux下每一个目录都有隐藏的. 和..目录，一定要把这两个排除掉。因为没有意义且会导致死循环*/
		if(strcmp(filename->d_name,".")==0||strcmp(filename->d_name,"..")==0)
		{
			continue;
		}
 
		/*获取文件信息，把信息放到s_buf中*/
		stat(file_path,&s_buf);
 
		/*判断是否目录*/ 
		if(S_ISDIR(s_buf.st_mode))
		{
			dir_oper(file_path);//递归调用
		}
 
		/*判断是否为普通文件*/
		if(S_ISREG(s_buf.st_mode))
		{
			// printf("%s\n",file_path);
			if(s_buf.st_nlink>=2){
                printf("%s\n",file_path);
            }
		}
    }
}
int main(int argc, char const *argv[]){
    char const*path = "lab5";
	struct stat s_buf;
 
	/*获取文件信息，把信息放到s_buf中*/
	stat(path,&s_buf);
 
	/*判断输入的文件路径是否目录，若是目录，则往下执行，分析目录下的文件*/
	if(S_ISDIR(s_buf.st_mode))
	{
		dir_oper(path);
	}
 
	/*若输入的文件路径是普通文件，则打印并退出程序*/
	else if(S_ISREG(s_buf.st_mode))
	{
		if(s_buf.st_nlink>=2){
            printf("%s\n",path);
        }
		return 0;
	}
 
	return 0;

}
#include "lib.h"
#include "types.h"
//#include <sys/types.h>
#define N 5

//sem_t forks[5];
//sem_t mutex,Fullbuffers,emptyBuffers;

// }
sem_t WriteMutex, CountMutex;
int Rcount;
 int uEntry(void) {
	sem_init(&WriteMutex,1);
	sem_init(&CountMutex,1);
	Rcount=0;
	write(3, (uint8_t *)&Rcount, 4, 0);
	for(int i = 0; i < 6; i++)
	{
		if(fork() == 0)
		{
			if(i < 3) {
				while (1)
				{
					sem_wait(&CountMutex);
					sleep(128);
					read(3, (uint8_t *)&Rcount, 4, 0);
					if(Rcount == 0){
						sem_wait(&WriteMutex);
						sleep(128);
					}
					++Rcount;
					write(3, (uint8_t *)&Rcount, 4, 0);
					sem_post(&CountMutex);
					sleep(128);
					printf("Reader %d: read, total %d reader\n", i, Rcount);
					sleep(128);
					sem_wait(&CountMutex);
					sleep(128);
					read(3, (uint8_t *)&Rcount, 4, 0);
					--Rcount;
					if(Rcount == 0){
						sem_post(&WriteMutex);
						sleep(128);
					}
					write(3, (uint8_t *)&Rcount, 4, 0);
					sem_post(&CountMutex);
					sleep(128);
				}
			}
			else {
				while(1)
					{
						sem_wait(&WriteMutex);
						sleep(128);
						printf("Writer %d: write\n", i-3);
						sleep(128);
						sem_post(&WriteMutex);
						sleep(128);
					}

			}
			break;
		}
	}

	while(1);
	sem_destroy(&WriteMutex);
	sem_destroy(&CountMutex);
	return 0;
	 /*
	sem_init(&mutex,1);
	sem_init(&Fullbuffers,0);
	sem_init(&emptyBuffers,3);
	for(int i=0;i<4;i++){
		if(fork()==0){
			while(1){
				sem_wait(&emptyBuffers);
				sleep(128);
				sem_wait(&mutex);
				sleep(128);
				printf("Producer %d: produce\n", i);
				sleep(128);
				sem_post(&mutex);
				sleep(128);
				sem_post(&Fullbuffers);
				sleep(128);
			}
		}
	}
	while(1){
		sem_wait(&Fullbuffers);
		sleep(128);
		sem_wait(&mutex);
		sleep(128);
		printf("Consumer : consume\n");
		sleep(128);
		sem_post(&mutex);
		sleep(128);
		sem_post(&emptyBuffers);
		sleep(128);
	}
	while(1);
	sem_destroy(&mutex);
	sem_destroy(&Fullbuffers);
	sem_destroy(&emptyBuffers);
	return 0;
	*/
/*
	for(int i=0;i<N;i++){
		sem_init(&forks[i],1);
	}

	for(int i=0;i<N;i++){
		int ret=fork();
		if(ret==0){
			while(1){
				printf("Philosopher %d: think\n", i);
				sleep(128);
				if(i % 2 == 0){
					sem_wait(&forks[i]);
					sleep(128);
					sem_wait(&forks[(i + 1) % N]);
					sleep(128);
				}
				else{
					sem_wait(&forks[(i + 1) % N]);
					sleep(128);
					sem_wait(&forks[i]);
					sleep(128);
				}
				printf("Philosopher %d: eat\n", i);
				sleep(128);
				sem_post(&forks[i]);
				sleep(128);
				sem_post(&forks[(i + 1) % N]);
				sleep(128);
			}
			return 0;
		}
		
	}
	while(1);
	for(int i=0;i<N;i++){
		sem_destroy(&forks[i]);
	}
	return 0;
	*/
	// For lab4.1
	// Test 'scanf' 
	/*
	int dec = 0;
	int hex = 0;
	char str[6];
	char cha = 0;
	int ret = 0;
	while(1){
		printf("Input:\" Test %%c Test %%6s %%d %%x\"\n");
		ret = scanf(" Test %c Test %6s %d %x", &cha, str, &dec, &hex);
		printf("Ret: %d; %c, %s, %d, %x.\n", ret, cha, str, dec, hex);
		if (ret == 4)
			break;
	}
	
	// For lab4.2
	// Test 'Semaphore'
	int i = 4;

	sem_t sem;
	printf("Father Process: Semaphore Initializing.\n");
	ret = sem_init(&sem, 2);
	if (ret == -1) {
		printf("Father Process: Semaphore Initializing Failed.\n");
		exit();
	}

	ret = fork();
	if (ret == 0) {
		while( i != 0) {
			i --;
			printf("Child Process: Semaphore Waiting.\n");
			sem_wait(&sem);
			printf("Child Process: In Critical Area.\n");
		}
		printf("Child Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}
	else if (ret != -1) {
		while( i != 0) {
			i --;
			printf("Father Process: Sleeping.\n");
			sleep(128);
			printf("Father Process: Semaphore Posting.\n");
			sem_post(&sem);
		}
		printf("Father Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}

	// For lab4.3
	// TODO: You need to design and test the philosopher problem.
	// Note that you can create your own functions.
	// Requirements are demonstrated in the guide.
	
	return 0;
	*/
}
